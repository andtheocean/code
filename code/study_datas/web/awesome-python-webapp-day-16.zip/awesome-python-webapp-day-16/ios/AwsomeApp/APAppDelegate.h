//
//  APAppDelegate.h
//  AwsomeApp
//
//  Created by Michael Liao on 6/5/14.
//  Copyright (c) 2014 iTranswarp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface APAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
